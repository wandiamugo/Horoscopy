import React, { Component } from 'react';
import './Header.css';

const Header = () => {
    return (
        <div className="header"><p>Your Daily Horoscope</p></div>
    )
}

export default Header;