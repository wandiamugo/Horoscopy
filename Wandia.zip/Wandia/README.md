### React Daily Horoscope made with [Aztro API](https://aztro.readthedocs.io/en/latest/)
#### Web app which show your daily horoscope.
It uses React to render the page and Aztro API to fetch the horoscopes.

#### How to use it
##### Just Clone and `npm start` it or  - [click here to see a demo](https://sergekashkin.github.io/daily_scope/).
![Image](https://user-images.githubusercontent.com/39168159/114576513-e285cb00-9c83-11eb-8f96-03388a61cbe6.gif)
